﻿using System.Diagnostics;
using System.Windows.Forms;

namespace WindyTownLauncher
{
    public partial class Donate : Form
    {
        public Donate()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //调用系统默认的浏览器
            Process.Start("explorer.exe", "https://afdian.net/@MrBrier");
        }
    }
}
