﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using System.Net;
using System.Text.RegularExpressions;

namespace WindyTownLauncher
{
    
    public partial class Form1 : Form
    {
        // 用来打开下载窗口
        // private DownW downw = DownW;
        // 用来读入文件
        
        // 用来存储java路径
        public string javapath;
        string[] fileDir = Directory.GetFiles(@".\ModsV\");
        public Form1()
        {
            InitializeComponent();
            if (Directory.Exists(@".\.minecraft") == false)
            {
                for (int number = 0; number != fileDir.Length - 1; number++)
                {
                    // 取目录左边 8指的是从左边数第八个往后取qwq
                    string textLeft = fileDir[number].Substring(8);
                    // 添加到checkedlistbox
                    checkedListBox1.Items.Add(textLeft.Substring(0, textLeft.Length - 4)); 
                }
                // 启用下载WT客户端按钮
                buttonDC.Enabled = true;
                return;
            }
            // 杜绝二次下载[doge]
            buttonDC.Enabled = false;
            string[] vdir = Directory.GetDirectories(@".\.minecraft\versions\");
            // 初始化
            // GetRight("qwq1234", "1234");
            string RAM = readini("save", "RAM");
            string Name = readini("save", "Name");
            string Version = readini("save", "Version");
            javapath = readini("save", "Java16");

            bjk_name.Text = Name;
            lbk.Text = Version;
            RAMM.Text = RAM;

            /* 以下代码是CheckedListBox的代码 */
            // for循环进行添加checkedlistbox
            for (int number = 0; number != fileDir.Length-1; number++)
            {
                // 取目录左边 8指的是从左边数第八个往后取qwq
                string textLeft = fileDir[number].Substring(8);
                // 添加到checkedlistbox
                checkedListBox1.Items.Add(textLeft.Substring(0, textLeft.Length-4));

            }
            /* 以下代码是Version的代码 */
            for(int jc = 0; jc != vdir.Length; jc++)
            {
                lbk.Items.Add(vdir[jc].Substring(22));
            }
        }
        // 运行游戏按钮被单击
        
        private void ButtonRun_Click(object sender, EventArgs e)
        {

            if(bjk_name.Text == "")
            {
                MessageBox.Show("请输入用户名！","warning");
                return;
            }
            else if(lbk.Text == "")
            {
                MessageBox.Show("请选择一个版本！", "warning");
                return;
            }
            else if(RAMM.Text == "")
            {
                MessageBox.Show("请输入一个RAM！", "warning");
                return;
            }
            else if(javapath == "")
            {
                MessageBox.Show("请输入Java路径！", "warning");
            }
            setini("save", "RAM", RAMM.Text);
            setini("save", "Name", bjk_name.Text);
            setini("save", "Version", lbk.Text);
            setini("save", "Java16", javapath);
            // for循环读取mod下载
            for (int i = 0; i != fileDir.Length-1; i++)
            {
                // 检查当前项是否被选中
                bool isChecked = checkedListBox1.GetItemChecked(i);
                // 如果当前项被选中
                if (isChecked)
                {
                    if (File.Exists(".\\.minecraft\\mods\\" + checkedListBox1.Items[i] + ".jar"))
                    {
                        Console.WriteLine("存在");
                        continue;
                    }

                    // 读入文件
                    StreamReader sr = new StreamReader(".\\ModsV\\" + checkedListBox1.Items[i] + ".txt", Encoding.Default);
                    // 写入URL
                    // File.WriteAllText(@".\\tempu.txt", sr.ReadLine().ToString());
                    downloadFile(".\\.minecraft\\mods\\" + checkedListBox1.Items[i].ToString() + ".jar", sr.ReadLine().ToString());
                    // 写入下载目录
                    // File.WriteAllText(@".\\tempf.txt", @".\\mods\\" + checkedListBox1.Items[i].ToString() + ".jar");
                    // 载入窗口
                    // DownW ac = new DownW();
                    // ac.MdiParent = this;
                    // ac.Show();

                    // ac.FormBorderStyle = FormBorderStyle.None; // 不显示from的边框
                    // 这里为非static调用 需要new一个对象qwq
                    // 显示窗口
                    // 调用下载函数 substring取文本右边
                    // dw.downinit(line.ToString(), @".\\mods\\" + checkedListBox1.Items[i].ToString().Substring(0, 4), checkedListBox1.Items[i].ToString().Substring(0, 4));
                    // Thread.Sleep();
                    /*
                    while (ac.isclose)
                    {
                        ac.Dispose();
                        ac.isclose = false;
                    }
                    */

                }
                // 如果当前项未被选中
                else
                {
                    // 跳过循环
                    continue;
                }
                // 启动游戏
            }
            string start = "@echo off\r\n" + "cd .minecraft\r\n" + "\"" + javapath + "\"" + " -XX:+UseG1GC -XX:-UseAdaptiveSizePolicy -XX:-OmitStackTraceInFastThrow -Dfml.ignoreInvalidMinecraftCertificates=True -Dfml.ignorePatchDiscrepancies=True -XX:HeapDumpPath=MojangTricksIntelDriversForPerformance_javaw.exe_minecraft.exe.heapdump -Djava.library.path=\".\\versions\\" + lbk.Text + "\\" + lbk.Text + "-natives\" -Dminecraft.launcher.brand=PCL2 -Dminecraft.launcher.version=226 -cp \".\\libraries\\com\\mojang\\blocklist\\1.0.5\\blocklist-1.0.5.jar;.\\libraries\\com\\mojang\\patchy\\2.1.6\\patchy-2.1.6.jar;.\\libraries\\com\\github\\oshi\\oshi-core\\5.7.5\\oshi-core-5.7.5.jar;.\\libraries\\net\\java\\dev\\jna\\jna\\5.8.0\\jna-5.8.0.jar;.\\libraries\\net\\java\\dev\\jna\\jna-platform\\5.8.0\\jna-platform-5.8.0.jar;.\\libraries\\org\\slf4j\\slf4j-api\\1.8.0-beta4\\slf4j-api-1.8.0-beta4.jar;.\\libraries\\org\\apache\\logging\\log4j\\log4j-slf4j18-impl\\2.14.1\\log4j-slf4j18-impl-2.14.1.jar;.\\libraries\\com\\ibm\\icu\\icu4j\\66.1\\icu4j-66.1.jar;.\\libraries\\com\\mojang\\javabridge\\1.1.23\\javabridge-1.1.23.jar;.\\libraries\\net\\sf\\jopt-simple\\jopt-simple\\5.0.3\\jopt-simple-5.0.3.jar;.\\libraries\\io\\netty\\netty-all\\4.1.25.Final\\netty-all-4.1.25.Final.jar;.\\libraries\\com\\google\\guava\\guava\\21.0\\guava-21.0.jar;.\\libraries\\org\\apache\\commons\\commons-lang3\\3.5\\commons-lang3-3.5.jar;.\\libraries\\commons-io\\commons-io\\2.5\\commons-io-2.5.jar;.\\libraries\\commons-codec\\commons-codec\\1.10\\commons-codec-1.10.jar;.\\libraries\\net\\java\\jinput\\jinput\\2.0.5\\jinput-2.0.5.jar;.\\libraries\\net\\java\\jutils\\jutils\\1.0.0\\jutils-1.0.0.jar;.\\libraries\\com\\mojang\\brigadier\\1.0.18\\brigadier-1.0.18.jar;.\\libraries\\com\\mojang\\datafixerupper\\4.0.26\\datafixerupper-4.0.26.jar;.\\libraries\\com\\google\\code\\gson\\gson\\2.8.0\\gson-2.8.0.jar;.\\libraries\\com\\mojang\\authlib\\2.3.31\\authlib-2.3.31.jar;.\\libraries\\org\\apache\\commons\\commons-compress\\1.8.1\\commons-compress-1.8.1.jar;.\\libraries\\org\\apache\\httpcomponents\\httpclient\\4.3.3\\httpclient-4.3.3.jar;.\\libraries\\commons-logging\\commons-logging\\1.1.3\\commons-logging-1.1.3.jar;.\\libraries\\org\\apache\\httpcomponents\\httpcore\\4.3.2\\httpcore-4.3.2.jar;.\\libraries\\it\\unimi\\dsi\\fastutil\\8.2.1\\fastutil-8.2.1.jar;.\\libraries\\org\\apache\\logging\\log4j\\log4j-api\\2.14.1\\log4j-api-2.14.1.jar;.\\libraries\\org\\apache\\logging\\log4j\\log4j-core\\2.14.1\\log4j-core-2.14.1.jar;.\\libraries\\org\\lwjgl\\lwjgl\\3.2.2\\lwjgl-3.2.2.jar;.\\libraries\\org\\lwjgl\\lwjgl-jemalloc\\3.2.2\\lwjgl-jemalloc-3.2.2.jar;.\\libraries\\org\\lwjgl\\lwjgl-openal\\3.2.2\\lwjgl-openal-3.2.2.jar;.\\libraries\\org\\lwjgl\\lwjgl-opengl\\3.2.2\\lwjgl-opengl-3.2.2.jar;.\\libraries\\org\\lwjgl\\lwjgl-glfw\\3.2.2\\lwjgl-glfw-3.2.2.jar;.\\libraries\\org\\lwjgl\\lwjgl-stb\\3.2.2\\lwjgl-stb-3.2.2.jar;.\\libraries\\org\\lwjgl\\lwjgl-tinyfd\\3.2.2\\lwjgl-tinyfd-3.2.2.jar;.\\libraries\\com\\mojang\\text2speech\\1.11.3\\text2speech-1.11.3.jar;.\\libraries\\net\\fabricmc\\tiny-mappings-parser\\0.2.2.14\\tiny-mappings-parser-0.2.2.14.jar;.\\libraries\\net\\fabricmc\\sponge-mixin\\0.9.4+mixin.0.8.2\\sponge-mixin-0.9.4+mixin.0.8.2.jar;.\\libraries\\net\\fabricmc\\tiny-remapper\\0.4.2\\tiny-remapper-0.4.2.jar;.\\libraries\\net\\fabricmc\\access-widener\\1.0.0\\access-widener-1.0.0.jar;.\\libraries\\net\\fabricmc\\fabric-loader-sat4j\\2.3.5.4\\fabric-loader-sat4j-2.3.5.4.jar;.\\libraries\\com\\google\\jimfs\\jimfs\\1.2-fabric\\jimfs-1.2-fabric.jar;.\\libraries\\org\\ow2\\asm\\asm\\9.1\\asm-9.1.jar;.\\libraries\\org\\ow2\\asm\\asm-analysis\\9.1\\asm-analysis-9.1.jar;.\\libraries\\org\\ow2\\asm\\asm-commons\\9.1\\asm-commons-9.1.jar;.\\libraries\\org\\ow2\\asm\\asm-tree\\9.1\\asm-tree-9.1.jar;.\\libraries\\org\\ow2\\asm\\asm-util\\9.1\\asm-util-9.1.jar;.\\libraries\\net\\fabricmc\\intermediary\\1.17.1\\intermediary-1.17.1.jar;.\\libraries\\net\\fabricmc\\fabric-loader\\0.11.6\\fabric-loader-0.11.6.jar;.\\versions\\" + lbk.Text + "\\" + lbk.Text + ".jar\" -Xmn1024m -Xmx" + RAMM.Text + "m net.fabricmc.loader.launch.knot.KnotClient --username " + bjk_name.Text + " --version " + lbk.Text + " --gameDir \".\" --assetsDir \".\\assets\" --assetIndex 1.17 --userType Legacy --versionType WindyTownLauncher --width 854 --height 480 \r\n pause"; // Cmd 命令
            string path = @".\qwq.bat";   // 保存到一个bat里
            File.WriteAllText(path, start, Encoding.Default);  // 打开文件
            // 下面是打开cmd
            Process p = new Process();//设定调用的程序名，不是系统目录的需要完整路径
            p.StartInfo.FileName = "qwq.bat";//传入执行参数
            if (DebugMode.Checked == false) // 检测调试模式是否开启
            {
                p.StartInfo.UseShellExecute = false; //是否重定向标准输入
                p.StartInfo.RedirectStandardInput = false; //是否重定向标准转出
                p.StartInfo.RedirectStandardOutput = false; //是否重定向错误
                p.StartInfo.RedirectStandardError = false; //执行时是不是显示窗口
                p.StartInfo.CreateNoWindow = true; //启动
            }
            p.Start();
            MessageBox.Show("游戏已经启动完毕！\n 如果您等了有一会没有看见窗口就请打开调试模式qwq", "Tips");
        }
        /*
        [Section]
　　     Key=Value
        */
        // 初始化ini相关
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName); // 读ini
        
        [DllImport("kernel32")]
        private static extern int WritePrivateProfileString(string lpApplicationName, string lpKeyName, string lpString, string lpFileName); // 写ini

        // 读ini函数
        string readini(string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(500);
            int i = GetPrivateProfileString(Section, Key, "", temp, 500, @".\wtl.ini");
            return temp.ToString();
        }

        // 写ini函数
        void setini(string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, @".\wtl.ini");
        }

        // 下载文件函数
        void downloadFile(string StrFileName, string StrUrl)
        {
            // StreamReader url = new StreamReader(@".\tempu.txt", Encoding.Default);
            // StreamReader fln = new StreamReader(@".\tempf.txt", Encoding.UTF8);

            // string StrFileName = fln.ReadLine().ToString();
            // string StrUrl = url.ReadLine().ToString();
            // label2.Text = "正在下载:" + StrFileName.Substring(0, StrFileName.Length-4);
            // url.Close();
            // fln.Close();
            long lStartPos = 0;
            FileStream fs;
            Console.WriteLine(StrFileName);
            if (File.Exists(StrFileName))// 另外如果文件已经下载完毕，就不需要再断点续传了，不然请求的range 会不合法会抛出异常。
            {
                fs = File.OpenWrite(StrFileName);
                lStartPos = fs.Length;
                fs.Seek(lStartPos, SeekOrigin.Current); //移动文件流中的当前指针 
            }
            else
            {
                fs = new FileStream(StrFileName, FileMode.Create);
                lStartPos = 0;
            }
            //打开网络连接 
            try
            {
                System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.HttpWebRequest.Create(StrUrl);
                if (lStartPos > 0)
                {
                    request.AddRange((int)lStartPos); //设置Range值
                }
                System.Net.WebResponse response = request.GetResponse();
                //向服务器请求，获得服务器回应数据流 
                Stream ns = response.GetResponseStream();
                long totalSize = response.ContentLength;

                long hasDownSize = 0;
                byte[] nbytes = new byte[512];//521,2048 etc
                int nReadSize = 0;
                nReadSize = ns.Read(nbytes, 0, nbytes.Length);
                while (nReadSize > 0)
                {
                    fs.Write(nbytes, 0, nReadSize);
                    nReadSize = ns.Read(nbytes, 0, 512);
                    hasDownSize += nReadSize;
                    // label1.Text = "" + hasDownSize + "/" + totalSize + "   (" + (((double)hasDownSize * 100 / totalSize).ToString("0.00")) + "%)";//显示下载百分比
                    labelj.Text = ((double)hasDownSize * 100 / totalSize).ToString("0.00") + "%"; // 显示下载百分比
                    Application.DoEvents();
                }
                fs.Close();
                ns.Close();
                labelj.Text = "下载完成";
            }
            catch (Exception ex)
            {
                fs.Close();
                MessageBox.Show("下载过程中出现错误:\n" + ex.ToString());
            }
        }
        // 取文本右边API
        /*
        public static string GetRight(string str, string s)
        {
            string temp = str.Substring(str.IndexOf(s), str.Length-str.Substring(0, str.IndexOf(s)).Length);
            Console.WriteLine("qwq:" + temp);
            return temp;
        }
        */
        // 选择java路径按钮被单击
        private void buttonSelect_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Multiselect = true,// 允许打开多个文件
                DefaultExt = ".exe",// 打开文件时显示的可选文件类型
                Filter = "java程序 | *.exe"// 打开多个文件
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                javapath = dialog.FileName;
                MessageBox.Show("设置Java路径成功:" + javapath,"Success");
            }
            // return dialog.FileNames;
            else
            {
                MessageBox.Show("返回文件路径失败","failed");
                return;
            }
        }
        // 全选
        private void buttonall_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < this.checkedListBox1.Items.Count; i++)
            {
                this.checkedListBox1.SetItemChecked(i, true);
            }
        }
        // 全不选
        private void buttonnall_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (checkedListBox1.GetItemChecked(i))
                {
                    checkedListBox1.SetItemChecked(i, false);
                }
            }
        }
        private void buttonDB_Click(object sender, EventArgs e)
        {
            // 氢氧根离子！！！
            // Console.WriteLine(checkedListBox1.GetItemText(checkedListBox1.SelectedItem));  
            File.Delete(@".\.minecraft\mods\" + checkedListBox1.GetItemText(checkedListBox1.SelectedItem) + ".jar");
            checkedListBox1.SetItemChecked(checkedListBox1.SelectedIndex, false);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int x = 0; x <= checkedListBox1.Items.Count-1; x++)
            {
                if (File.Exists(@".\.minecraft\mods\" + checkedListBox1.Items[x] + ".jar"))
                {
                    checkedListBox1.SetItemChecked(x, true);
                }
            }
        }

        private void buttonDown16_Click(object sender, EventArgs e)
        {
            //调用系统默认的浏览器
            Process.Start("explorer.exe", "https://www.oracle.com/java/technologies/downloads/#java16");
        }

        private void buttonZJ_Click(object sender, EventArgs e)
        {
            Donate d = new Donate();
            d.Show();
        }

        private void buttonDC_Click(object sender, EventArgs e)
        {
            buttonDC.Enabled = false; // 杜绝二次下载[doge]
            downloadFile(@".\.minecraft.zip", "https://mirror.ghproxy.com/https://github.com/xiaohuihui1022/windytown/releases/download/master/default.minecraft.zip");
            Process pro = new Process();
            string path = @".\解压脚本.bat";
            FileInfo file = new FileInfo(path);
            pro.StartInfo.WorkingDirectory = file.Directory.FullName;
            pro.StartInfo.FileName = path;
            pro.Start();
            // 解压脚本运行完毕之后删除minecraft里的mod：
            File.Delete(@".\.minecraft\mods\*.*");
            // 重新读入版本 刷新版本列表
            string[] vdir = Directory.GetDirectories(@".\.minecraft\versions\");
            for (int jc = 0; jc != vdir.Length; jc++)
            {
                lbk.Items.Add(vdir[jc].Substring(22));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Update
            string now_v = "1.0"; // 定义版本号
            // 网站源码抓取函数
            string GetWebClient(string url)
            {
                string strHTML = "";
                WebClient myWebClient = new WebClient();
                Stream myStream = myWebClient.OpenRead(url);
                StreamReader sr = new StreamReader(myStream, Encoding.GetEncoding("utf-8"));
                strHTML = sr.ReadToEnd();
                myStream.Close();
                return strHTML;
            }
            Regex v = new Regex("(?<=(" + "最新版本：【" + "))[.\\s\\S]*?(?=(" + "】" + "))", RegexOptions.Multiline | RegexOptions.Singleline);
            Regex rizhi = new Regex("(?<=(" + "更新日志：【" + "))[.\\s\\S]*?(?=(" + "】" + "))", RegexOptions.Multiline | RegexOptions.Singleline);
            Regex dizhi = new Regex("(?<=(" + "下载地址：【" + "))[.\\s\\S]*?(?=(" + "】" + "))", RegexOptions.Multiline | RegexOptions.Singleline);
            string uptade = GetWebClient("https://note.youdao.com/yws/public/note/63f2f3a1615169abe42521f5f99ed351");
            string newest_v = v.Match(uptade).Value; // 最新版本
            string rizhis = rizhi.Match(uptade).Value; // 更新日志
            string downurl = dizhi.Match(uptade).Value; // 下载地址
            if(now_v != newest_v)
            {
                File.WriteAllText(@".\更新地址.txt", downurl, Encoding.Default);  // 写入下载地址
                MessageBox.Show("有新的版本可以下载了！！ \n更新日志：" + rizhis + "\n下载地址已经存放到软件根目录下 请自行下载 也可通过WindyTown群文件下载");
            }
        }
    }
}