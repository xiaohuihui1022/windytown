﻿namespace WindyTownLauncher
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bjk_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonall = new System.Windows.Forms.Button();
            this.buttonnall = new System.Windows.Forms.Button();
            this.buttonDB = new System.Windows.Forms.Button();
            this.buttonZJ = new System.Windows.Forms.Button();
            this.buttonSelect = new System.Windows.Forms.Button();
            this.buttonDown16 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonRun = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelj = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.RAMM = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lbk = new System.Windows.Forms.ComboBox();
            this.DebugMode = new System.Windows.Forms.CheckBox();
            this.buttonDC = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(418, 29);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(234, 346);
            this.checkedListBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "用户名：";
            // 
            // bjk_name
            // 
            this.bjk_name.Location = new System.Drawing.Point(74, 21);
            this.bjk_name.Name = "bjk_name";
            this.bjk_name.Size = new System.Drawing.Size(288, 23);
            this.bjk_name.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "版本：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(415, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "MOD选择:";
            // 
            // buttonall
            // 
            this.buttonall.Location = new System.Drawing.Point(487, 0);
            this.buttonall.Name = "buttonall";
            this.buttonall.Size = new System.Drawing.Size(75, 23);
            this.buttonall.TabIndex = 6;
            this.buttonall.Text = "全选";
            this.buttonall.UseVisualStyleBackColor = true;
            this.buttonall.Click += new System.EventHandler(this.buttonall_Click);
            // 
            // buttonnall
            // 
            this.buttonnall.Location = new System.Drawing.Point(577, 0);
            this.buttonnall.Name = "buttonnall";
            this.buttonnall.Size = new System.Drawing.Size(75, 23);
            this.buttonnall.TabIndex = 7;
            this.buttonnall.Text = "全不选";
            this.buttonnall.UseVisualStyleBackColor = true;
            this.buttonnall.Click += new System.EventHandler(this.buttonnall_Click);
            // 
            // buttonDB
            // 
            this.buttonDB.Location = new System.Drawing.Point(418, 383);
            this.buttonDB.Name = "buttonDB";
            this.buttonDB.Size = new System.Drawing.Size(115, 23);
            this.buttonDB.TabIndex = 8;
            this.buttonDB.Text = "删除蓝底mod";
            this.buttonDB.UseVisualStyleBackColor = true;
            this.buttonDB.Click += new System.EventHandler(this.buttonDB_Click);
            // 
            // buttonZJ
            // 
            this.buttonZJ.Location = new System.Drawing.Point(549, 383);
            this.buttonZJ.Name = "buttonZJ";
            this.buttonZJ.Size = new System.Drawing.Size(103, 23);
            this.buttonZJ.TabIndex = 9;
            this.buttonZJ.Text = "给点赞助吧TAT";
            this.buttonZJ.UseVisualStyleBackColor = true;
            this.buttonZJ.Click += new System.EventHandler(this.buttonZJ_Click);
            // 
            // buttonSelect
            // 
            this.buttonSelect.Location = new System.Drawing.Point(12, 110);
            this.buttonSelect.Name = "buttonSelect";
            this.buttonSelect.Size = new System.Drawing.Size(125, 39);
            this.buttonSelect.TabIndex = 10;
            this.buttonSelect.Text = "选择java16路径";
            this.buttonSelect.UseVisualStyleBackColor = true;
            this.buttonSelect.Click += new System.EventHandler(this.buttonSelect_Click);
            // 
            // buttonDown16
            // 
            this.buttonDown16.Location = new System.Drawing.Point(256, 110);
            this.buttonDown16.Name = "buttonDown16";
            this.buttonDown16.Size = new System.Drawing.Size(125, 39);
            this.buttonDown16.TabIndex = 11;
            this.buttonDown16.Text = "下载java16";
            this.buttonDown16.UseVisualStyleBackColor = true;
            this.buttonDown16.Click += new System.EventHandler(this.buttonDown16_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(12, 152);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(316, 153);
            this.label5.TabIndex = 12;
            this.label5.Text = "警告：\r\n如果启动游戏之后报错有OpenGL字样\r\n请更新您的显卡驱动(更新过程中出任何差错均与本人无关)\r\n如果更新了还不行\r\n就说明你电脑太老了\r\n如果启动之" +
    "后fabric报错\r\n请检查mod是否兼容\r\n或mod有没有冲突\r\n最好翻译一下上边的英文";
            // 
            // buttonRun
            // 
            this.buttonRun.Font = new System.Drawing.Font("微软雅黑", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonRun.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.buttonRun.Location = new System.Drawing.Point(15, 332);
            this.buttonRun.Name = "buttonRun";
            this.buttonRun.Size = new System.Drawing.Size(347, 64);
            this.buttonRun.TabIndex = 13;
            this.buttonRun.Text = "启动游戏";
            this.buttonRun.UseVisualStyleBackColor = true;
            this.buttonRun.Click += new System.EventHandler(this.ButtonRun_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelj
            // 
            this.labelj.AutoSize = true;
            this.labelj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelj.Location = new System.Drawing.Point(263, 262);
            this.labelj.Name = "labelj";
            this.labelj.Size = new System.Drawing.Size(0, 17);
            this.labelj.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 15;
            this.label3.Text = "RAM:";
            // 
            // RAMM
            // 
            this.RAMM.Location = new System.Drawing.Point(74, 80);
            this.RAMM.Name = "RAMM";
            this.RAMM.Size = new System.Drawing.Size(100, 23);
            this.RAMM.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(180, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "MB";
            // 
            // lbk
            // 
            this.lbk.FormattingEnabled = true;
            this.lbk.Location = new System.Drawing.Point(74, 49);
            this.lbk.Name = "lbk";
            this.lbk.Size = new System.Drawing.Size(288, 25);
            this.lbk.TabIndex = 18;
            // 
            // DebugMode
            // 
            this.DebugMode.AutoSize = true;
            this.DebugMode.Location = new System.Drawing.Point(287, 294);
            this.DebugMode.Name = "DebugMode";
            this.DebugMode.Size = new System.Drawing.Size(75, 21);
            this.DebugMode.TabIndex = 19;
            this.DebugMode.Text = "调试模式";
            this.DebugMode.UseVisualStyleBackColor = true;
            // 
            // buttonDC
            // 
            this.buttonDC.Location = new System.Drawing.Point(143, 109);
            this.buttonDC.Name = "buttonDC";
            this.buttonDC.Size = new System.Drawing.Size(107, 39);
            this.buttonDC.TabIndex = 20;
            this.buttonDC.Text = "下载WT客户端";
            this.buttonDC.UseVisualStyleBackColor = true;
            this.buttonDC.Click += new System.EventHandler(this.buttonDC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 408);
            this.Controls.Add(this.buttonDC);
            this.Controls.Add(this.DebugMode);
            this.Controls.Add(this.lbk);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.RAMM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelj);
            this.Controls.Add(this.buttonRun);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.buttonDown16);
            this.Controls.Add(this.buttonSelect);
            this.Controls.Add(this.buttonZJ);
            this.Controls.Add(this.buttonDB);
            this.Controls.Add(this.buttonnall);
            this.Controls.Add(this.buttonall);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bjk_name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkedListBox1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "WindyTownLauncher";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox bjk_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonall;
        private System.Windows.Forms.Button buttonnall;
        private System.Windows.Forms.Button buttonDB;
        private System.Windows.Forms.Button buttonZJ;
        private System.Windows.Forms.Button buttonSelect;
        private System.Windows.Forms.Button buttonDown16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonRun;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelj;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox RAMM;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox lbk;
        private System.Windows.Forms.CheckBox DebugMode;
        private System.Windows.Forms.Button buttonDC;
    }
}

